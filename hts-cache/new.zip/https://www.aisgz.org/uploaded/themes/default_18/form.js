/*!
 * American International School of Guangzhou - default_18
 * @link: https://aisgzorg.finalsite.com
 * Site Template: newclientcustom
 * Built By: Umar Hamza
 * Project Manager: Lori Foster
 * Designer: Jonny Young
 * ==== Git Info ====
 * Branch Name: master
 * Build Version: 1.0.0
 * Git Tag: ebfb747
 * Last built by: Jesse
 */
buildinfo={buildname:"fs-webpack-build",ver:"1.0.0",template:"newclientcustom"},function(e){function n(r){if(t[r])return t[r].exports;var o=t[r]={i:r,l:!1,exports:{}};return e[r].call(o.exports,o,o.exports,n),o.l=!0,o.exports}var t={};n.m=e,n.c=t,n.d=function(e,t,r){n.o(e,t)||Object.defineProperty(e,t,{configurable:!1,enumerable:!0,get:r})},n.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return n.d(t,"a",t),t},n.o=function(e,n){return Object.prototype.hasOwnProperty.call(e,n)},n.p="",n(n.s=25)}({25:function(e,n){}});