<!DOCTYPE html>
<html class="fsComposerFormEmbed">


<head><script type="text/javascript" src="/cf_scripts/scripts/cfform.js"></script>
<script type="text/javascript" src="/cf_scripts/scripts/masks.js"></script>

	<meta http-equiv="Content-type" content="text/html; charset=utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" >

	<script src="https://securejs.finalsite.com/190215/javascript/jQuery/jquery.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="https://securejs.finalsite.com/190215/javascript/jQuery/jquery-migrate-1.2.1.fs-modified.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="https://securejs.finalsite.com/190215/javascript/jQuery/jquery.ui.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="https://securejs.finalsite.com/190215/javascript/iFrameResizer/iframeResizer.contentWindow.min.js" type="text/javascript" charset="utf-8"></script>
	<script type="text/javascript" charset="utf-8">
		pathprefix = "../";
	</script>
   	<script src="https://securejs.finalsite.com/190215/javascript/fs_global.js" type="text/javascript" charset="utf-8"></script>
	<script type="text/javascript" charset="utf-8">
		$j = jQuery.noConflict();
		var siteDatemask = "md";
		var siteTimemask = "12";

		window.name = 'finalsiteadmin_aisgzorg';

		addHeight = 70;

		function popMedia(thevar) {
			var mh_url = pathprefix + "cf_media/popheight.cfm";

			mediaAction(thevar);
		}

		$j(document).ready(function(){
			$j('#leftFrame .btnLink').removeClass('on').each(function(i){
				if( $j(this).attr('href') == document.location.pathname + document.location.search ){
					$j(this).addClass('on');
				}
			});
		});

		siteurl = "https://www.aisgz.org";
		siteSSLurl = "https://www.aisgz.org";
		isEditor = true;
		basepath = '../';
		baseurl = "../";

	</script>
	<script src="scripts/adminview.js?decache=20111004064200" type="text/javascript" charset="utf-8"></script>

	
					<link rel="stylesheet" href="../uploaded/themes/default_18/main.css" type="text/css" media="screen" charset="utf-8">
				
					<script src="../uploaded/themes/default_18/form.js" type="text/javascript" charset="utf-8"></script>
				
	<link rel="stylesheet" href="https://www.aisgz.org/styles.cfm" type="text/css" media="screen" charset="utf-8">
<script src="https://securejs.finalsite.com/190215/javascript/jQuery/jquery-migrate-1.2.1.fs-modified.js?f=0" type="javascript"></script>

					<style type="text/css">
						.required{ color:#990033; font-weight:bold; }
					</style>

					<link rel="stylesheet" href="https://www.aisgz.org/cf_forms/scripts/formPlugin.css?decache=CA762033-D0F0-FDB5-7E71EBB5D42FCF9F" type="text/css" charset="utf-8">

					<link rel="stylesheet" href="https://securejs.finalsite.com/190215/javascript/jQuery/themes/base/ui.all.css?decache=190215" type="text/css" title="no title" charset="utf-8">
					<link rel="stylesheet" href="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/validationEngine.jquery.css?decache=190215" type="text/css" charset="utf-8" />
					<link rel="stylesheet" href="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/fsNumberSpinner/jquery.fsNumberSpinner.css?decache=190215" type="text/css" charset="utf-8" />

					
					

					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/jquery.ui.min.js?decache=190215" type="text/javascript"></script>

					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/jquery.json.js?decache=190215" type="text/javascript"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/jquery.base64.js?decache=190215" type="text/javascript"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/jquery.finalsiteValidator.min.js?decache=190215" type="text/javascript" charset="utf-8"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/jquery.uuid.min.js?decache=190215" type="text/javascript" charset="utf-8"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/jquery.finalsiteSumInputs.min.js?decache=190215" type="text/javascript" charset="utf-8"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/jquery.scrollTo-1.4.2-min.js?decache=190215" type="text/javascript"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/autonumeric/autoNumeric.min.js?decache=190215" type="text/javascript"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/jquery.autoLoader.js?decache=190215" type="text/javascript"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/fsNumberSpinner/jquery.fsNumberSpinner.min.js?decache=190215" type="text/javascript"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/fsNumberBox/jquery.fsNumberBox.min.js?decache=190215" type="text/javascript"></script>

					
					

					<script type="text/javascript" charset="utf-8">
						// <![CDATA[

						// we need to count how many forms require a warn before unload
						// for example, banners do not
						var warnBeforeUnloadCount = 0;

						// ]]>
					</script>

					<script type="text/javascript" charset="utf-8">
						var jsPath = "https://www.aisgz.org/";
						var formPluginRequestMode = "direct";

						// set our options for this form
						$j(document).ready(function() {
							

							$j("#form_95").data( "formOptions", {"submitButtonText":"Send Request","formWidth":950,"expiredFormText":"This form has expired.","maxFormWidth":938,"defaultLabelPosition":"top","defaultTipPosition":"below"} );
							
						} );

						// we will keep extending this object
						fs = {};
						isAdmin = false;
						// for date conditionals
						nowTS = 201905171620;
					</script>
					
						
						<script src="https://www.aisgz.org/cf_forms/scripts/formPlugin.min.js?decache=CA762033-D0F0-FDB5-7E71EBB5D42FCF9F" type="text/javascript" charset="utf-8"></script>
					
					<script type="text/javascript" charset="utf-8">
						// <![CDATA[
						warnBeforeUnloadCount++;
						// ]]>
					</script>
				
				<script type="text/javascript" charset="utf-8">
					isQuiz = false;
					
				</script>
			<script type="text/javascript">
<!--
    _CF_checkform_95 = function(_CF_this)
    {
        //reset on submit
        _CF_error_exists = false;
        _CF_error_messages = new Array();
        _CF_error_fields = new Object();
        _CF_FirstErrorField = null;


        //display error messages and return success
        if( _CF_error_exists )
        {
            if( _CF_error_messages.length > 0 )
            {
                // show alert() message
                _CF_onErrorAlert(_CF_error_messages);
                // set focus to first form error, if the field supports js focus().
                if( _CF_this[_CF_FirstErrorField].type == "text" )
                { _CF_this[_CF_FirstErrorField].focus(); }

            }
            return false;
        }else {
            return true;
        }
    }
//-->
</script>
</head>


<body>

	

	
	<a name="formAnchor_95"></a>

	

				<div class="subGroup">

					
					<script type="text/javascript">
						cp = {};
						fs = $j.extend( fs, {"revisionNumber":0,"submitID":0,"IFRAMEMODE":false,"submissionExists":0,"CMD_CF_FORMS":"","HIDDENELEMENTS":"","REQUESTMODE":"direct","ISFRAMED":false,"formID":0} );
						idSuffix = "";
						hasReg = false;
						rg = {};
						wlClaim = [];
						wlClaimBindIDs = [];
						regKey = "";
						ro = {};
						adminBypass = false;
						aSess = false;

						
						
					</script>

					
					<form name="form_95" id="form_95" action="/cf_forms/view.cfm?composer_style=%252Fuploaded%252Fthemes%252Fdefault%5F18%252Fmain%2Ecss%257C%252Fuploaded%252Fthemes%252Fdefault%5F18%252Fform%2Ejs%2C%2Fuploaded%2Fthemes%2Fdefault%5F18%2Fmain%2Ecss%7C%2Fuploaded%2Fthemes%2Fdefault%5F18%2Fform%2Ejs&CSB=off&adminBypass=false&verbose=0&formID=95#formAnchor_95" method="post" class="cf_form disableEnter" enctype="multipart/form-data" onsubmit="return _CF_checkform_95(this)"><div class="mainGroupSub targetForm" id="targetForm_95"><div class="formPage" id="formPage_95_1"><div class="elementRow"><div class="elementContainer field_3363 " id="elementContainer_3706"><label for="el_3706" class="required">称呼* </label><div class="elementBody"><select name="el_3706" id="el_3706" class="fsValidate[required]" data-elbindid="3363" data-max="999999"><option value="">Please Select&hellip;</option><option data-label="先生" data-value="Item One" data-price="0.0000" data-optionID="19671" data-bindID="02034020-4340-440c-9db6-d644f2b0d0cc" value="02034020-4340-440c-9db6-d644f2b0d0cc">先生</option><option data-label="太太" data-value="Item Two" data-price="0.0000" data-optionID="19672" data-bindID="c1b16f61-44b8-4117-9b5f-7417bf16ba80" value="c1b16f61-44b8-4117-9b5f-7417bf16ba80">太太</option><option data-label="小姐" data-value="Item Three" data-price="0.0000" data-optionID="19673" data-bindID="9d22bc9a-521f-4338-80cf-988df7912092" value="9d22bc9a-521f-4338-80cf-988df7912092">小姐</option><option data-label="博士" data-value="" data-price="0.0000" data-optionID="19674" data-bindID="3489ed99-9373-4a5f-81aa-4ebf03dc4e76" value="3489ed99-9373-4a5f-81aa-4ebf03dc4e76">博士</option><option data-label="女士" data-value="" data-price="0.0000" data-optionID="19675" data-bindID="9245d352-a732-4c10-a3c3-474f399e05d5" value="9245d352-a732-4c10-a3c3-474f399e05d5">女士</option><option data-label="教授" data-value="" data-price="0.0000" data-optionID="19676" data-bindID="2aec3ecc-97aa-4260-bcdd-c7d7fb3b5265" value="2aec3ecc-97aa-4260-bcdd-c7d7fb3b5265">教授</option><option data-label="牧师" data-value="" data-price="0.0000" data-optionID="19677" data-bindID="fe290d3c-f4d6-4abc-a824-3255692b34f1" value="fe290d3c-f4d6-4abc-a824-3255692b34f1">牧师</option><option data-label="其他" data-value="" data-price="0.0000" data-optionID="19678" data-bindID="d725fe80-f263-4def-9468-54dcf2b37566" value="d725fe80-f263-4def-9468-54dcf2b37566">其他</option></select></div></div></div><div class="elementRow"><div class="elementColumn" style="width: 34.36em;"><div class="elementContainer field_3364 " id="elementContainer_3707"><label for="el_3707" class="required">家长名字* </label><div class="elementBody"><input type="text" name="el_3707" data-elbindid="3364" data-prefill="false" data-prefillDataField="false" id="el_3707" value="" size="50" maxlength="255" class="fsValidate[required]" /></div></div></div><div class="elementColumn" style="width: 34.46em;"><div class="elementContainer field_3365 " id="elementContainer_3708"><label for="el_3708" class="required">家长姓氏* </label><div class="elementBody"><input type="text" name="el_3708" data-elbindid="3365" data-prefill="false" data-prefillDataField="false" id="el_3708" value="" size="50" maxlength="255" class="fsValidate[required]" /></div></div></div></div><div class="elementRow"><div class="elementColumn" style="width: 34.36em;"><div class="elementContainer field_3366 " id="elementContainer_3709"><label for="el_3709" class="required">家长Email* </label><div class="elementBody"><input type="text" name="el_3709" data-elbindid="3366" data-prefill="false" data-prefillDataField="Email" id="el_3709" value="" size="50" maxlength="255" class="fsValidate[required,email]" /></div></div></div><div class="elementColumn" style="width: 34.46em;"><div class="elementContainer field_3367 " id="elementContainer_3710"><label for="el_3710" class="required">家长电话* </label><div class="elementBody"><input type="text" name="el_3710" data-elbindid="3367" data-prefill="false" data-prefillDataField="false" id="el_3710" value="" size="50" maxlength="255" class="fsValidate[required,onlyNumber]" /></div></div></div></div><div class="elementRow"><div class="elementColumn" style="width: 34.36em;"><div class="elementContainer field_3368 " id="elementContainer_3711"><label for="el_3711" class="required">学生名字* </label><div class="elementBody"><input type="text" name="el_3711" data-elbindid="3368" data-prefill="false" data-prefillDataField="false" id="el_3711" value="" size="50" maxlength="255" class="fsValidate[required]" /></div></div></div><div class="elementColumn" style="width: 34.46em;"><div class="elementContainer field_3369 " id="elementContainer_3712"><label for="el_3712" class="required">学生姓氏* </label><div class="elementBody"><input type="text" name="el_3712" data-elbindid="3369" data-prefill="false" data-prefillDataField="false" id="el_3712" value="" size="50" maxlength="255" class="fsValidate[required]" /></div></div></div></div><div class="elementRow"><div class="elementColumn" style="width: 34.36em;"><div class="elementContainer field_3370 " id="elementContainer_3713"><label for="el_3713" class="required">学生出生日期* </label><div class="elementBody"><input type="text" name="el_3713" data-elbindid="3370" data-prefill="false" data-prefillDataField="false" id="el_3713" value="" size="20" maxlength="255" class="fsValidate[required]" /></div></div></div><div class="elementColumn" style="width: 12.91em;"><div class="elementContainer field_3371 " id="elementContainer_3714"><label for="el_3714" class="required">申请年级* </label><div class="elementBody"><select name="el_3714" id="el_3714" class="fsValidate[required]" data-elbindid="3371" data-max="999999"><option value="">Please Select&hellip;</option><option data-label="Pre-K" data-value="-1" data-price="0.0000" data-optionID="19679" data-bindID="43e3fb58-9036-4352-9d15-ffc0aaa32f0e" value="43e3fb58-9036-4352-9d15-ffc0aaa32f0e">Pre-K</option><option data-label="Kindergarten" data-value="0" data-price="0.0000" data-optionID="19680" data-bindID="a4429150-8817-488f-8ed1-acd637aec68f" value="a4429150-8817-488f-8ed1-acd637aec68f">Kindergarten</option><option data-label="1" data-value="1" data-price="0.0000" data-optionID="19681" data-bindID="78ff4fcb-82b4-47fd-b415-114740ecf7be" value="78ff4fcb-82b4-47fd-b415-114740ecf7be">1</option><option data-label="2" data-value="2" data-price="0.0000" data-optionID="19682" data-bindID="98d978d8-369d-42d8-8330-657a9e60500a" value="98d978d8-369d-42d8-8330-657a9e60500a">2</option><option data-label="3" data-value="3" data-price="0.0000" data-optionID="19683" data-bindID="48795df4-8087-40b0-b9fd-a466794c8b5b" value="48795df4-8087-40b0-b9fd-a466794c8b5b">3</option><option data-label="4" data-value="4" data-price="0.0000" data-optionID="19684" data-bindID="e8ca3d4d-a8af-4206-b690-573cb3cbb3c2" value="e8ca3d4d-a8af-4206-b690-573cb3cbb3c2">4</option><option data-label="5" data-value="5" data-price="0.0000" data-optionID="19685" data-bindID="f3e5bdc5-3ba4-4a5c-8205-674717ffcd81" value="f3e5bdc5-3ba4-4a5c-8205-674717ffcd81">5</option><option data-label="6" data-value="6" data-price="0.0000" data-optionID="19686" data-bindID="c1167a57-2d2c-48b9-b584-76159b83d38d" value="c1167a57-2d2c-48b9-b584-76159b83d38d">6</option><option data-label="7" data-value="7" data-price="0.0000" data-optionID="19687" data-bindID="81d00b22-9f10-4c3c-8ff6-2c5090bd57ae" value="81d00b22-9f10-4c3c-8ff6-2c5090bd57ae">7</option><option data-label="8" data-value="8" data-price="0.0000" data-optionID="19688" data-bindID="e44ab6b1-0d09-4992-939f-7a4a1634b72f" value="e44ab6b1-0d09-4992-939f-7a4a1634b72f">8</option><option data-label="9" data-value="9" data-price="0.0000" data-optionID="19689" data-bindID="4406f815-e869-4a49-b230-bfaa1e881c88" value="4406f815-e869-4a49-b230-bfaa1e881c88">9</option><option data-label="10" data-value="10" data-price="0.0000" data-optionID="19690" data-bindID="9d5845da-0643-4cc1-b603-45625042690f" value="9d5845da-0643-4cc1-b603-45625042690f">10</option><option data-label="11" data-value="11" data-price="0.0000" data-optionID="19691" data-bindID="5b0dcc91-4c2b-4642-8918-b5cc083752c5" value="5b0dcc91-4c2b-4642-8918-b5cc083752c5">11</option><option data-label="12" data-value="12" data-price="0.0000" data-optionID="19692" data-bindID="23ebecfc-a2de-4b9c-ba50-a22bc2cdafb9" value="23ebecfc-a2de-4b9c-ba50-a22bc2cdafb9">12</option></select></div></div></div></div><div class="elementRow"><div class="elementContainer field_3601 " id="elementContainer_3715"><label for="el_3715" class="required">申请入学学年* </label><div class="elementBody"><input type="text" name="el_3715" data-elbindid="3601" data-prefill="false" data-prefillDataField="false" id="el_3715" value="" size="20" maxlength="255" class="fsValidate[required]" /></div></div></div><div class="elementRow"><div class="elementContainer field_3602 " id="elementContainer_3716"><label for="el_3716" class="required">学生护照国籍* </label><div class="elementBody"><input type="text" name="el_3716" data-elbindid="3602" data-prefill="false" data-prefillDataField="false" id="el_3716" value="" size="20" maxlength="255" class="fsValidate[required]" /></div></div></div><div class="elementRow"><div class="elementContainer field_3604 " id="elementContainer_3717"><label for="el_3717" class="required">现就读学校* </label><div class="elementBody"><input type="text" name="el_3717" data-elbindid="3604" data-prefill="false" data-prefillDataField="false" id="el_3717" value="" size="20" maxlength="255" class="fsValidate[required]" /></div></div></div><div class="elementRow"><div class="elementContainer field_3605 " id="elementContainer_3718"><label for="el_3718" class="required">现就读年级* </label><div class="elementBody"><input type="text" name="el_3718" data-elbindid="3605" data-prefill="false" data-prefillDataField="false" id="el_3718" value="" size="20" maxlength="255" class="fsValidate[required]" /></div></div></div><div class="elementRow"><div class="elementContainer field_3373 " id="elementContainer_3719"><label for="el_3719" class="required">参观人数* </label><div class="elementBody"><select name="el_3719" id="el_3719" class="fsValidate[required]" data-elbindid="3373" data-max="999999"><option value="">Please Select&hellip;</option><option data-label="1" data-value="Item One" data-price="0.0000" data-optionID="19693" data-bindID="9ff94662-d241-42ab-8f06-b2db57bc7219" value="9ff94662-d241-42ab-8f06-b2db57bc7219">1</option><option data-label="2" data-value="Item Two" data-price="0.0000" data-optionID="19694" data-bindID="53a8dc10-7382-4de0-9a4b-fe1e102bef4c" value="53a8dc10-7382-4de0-9a4b-fe1e102bef4c">2</option><option data-label="3" data-value="Item Three" data-price="0.0000" data-optionID="19695" data-bindID="34db697e-5ead-4a2f-a3c9-cad7dc921493" value="34db697e-5ead-4a2f-a3c9-cad7dc921493">3</option><option data-label="4" data-value="" data-price="0.0000" data-optionID="19696" data-bindID="c9d7dc2b-f8df-47c7-be2d-c15bf1507422" value="c9d7dc2b-f8df-47c7-be2d-c15bf1507422">4</option></select></div><script type="text/javascript"> $j(document).ready(function() { setConditionalElement( "#elementContainer_3719", "#elementContainer_3721", '["f9604124-1f74-44a0-a745-2c9169276e68","7be81998-4d40-4931-b832-eac5b1ab1de9"]', true ); $j("#elementContainer_3719").addClass(""); }); </script></div></div><div class="elementRow"><div class="elementContainer field_3374 " id="elementContainer_3720"><div class="groupLabel required"><label for="el_3720" style="overflow: hidden;">请选择适合你的参观时间*</label></div><div class="elementBody"><div class="descText">我校会与你再联络确认参观时间。&#8203;</div><fieldset id="el_3720" class="fsValidate[required]"><label for="el_3720_0"><input data-label="星期一 11:00am" data-value="Checkbox" data-price="0.0000" data-optionID="19697" data-bindID="400cac3c-f6dc-43cc-a352-d670db818f93" id="el_3720_0" data-elbindid="3374" data-max="999999" type="checkbox" value="400cac3c-f6dc-43cc-a352-d670db818f93" name="el_3720" > 星期一 11:00am&nbsp; </label><label for="el_3720_1"><input data-label="星期一 2:00pm" data-value="" data-price="0.0000" data-optionID="19698" data-bindID="e2796797-3083-4668-843e-1aaa14c385e4" id="el_3720_1" data-elbindid="3374" data-max="999999" type="checkbox" value="e2796797-3083-4668-843e-1aaa14c385e4" name="el_3720" > 星期一 2:00pm&nbsp; </label><label for="el_3720_2"><input data-label="星期一 3:00pm" data-value="" data-price="0.0000" data-optionID="19699" data-bindID="100a968b-e431-4255-9ee1-0779926b68b1" id="el_3720_2" data-elbindid="3374" data-max="999999" type="checkbox" value="100a968b-e431-4255-9ee1-0779926b68b1" name="el_3720" > 星期一 3:00pm&nbsp; </label><label for="el_3720_3"><input data-label="星期二 9:00am" data-value="" data-price="0.0000" data-optionID="19700" data-bindID="868f3208-4859-4cfa-9b66-871ffcd729e6" id="el_3720_3" data-elbindid="3374" data-max="999999" type="checkbox" value="868f3208-4859-4cfa-9b66-871ffcd729e6" name="el_3720" > 星期二 9:00am&nbsp; </label><label for="el_3720_4"><input data-label="星期二 10:00am" data-value="" data-price="0.0000" data-optionID="19701" data-bindID="1c63248e-64db-4612-b07e-6e26188739a2" id="el_3720_4" data-elbindid="3374" data-max="999999" type="checkbox" value="1c63248e-64db-4612-b07e-6e26188739a2" name="el_3720" > 星期二 10:00am&nbsp; </label><label for="el_3720_5"><input data-label="星期二 11:00am" data-value="" data-price="0.0000" data-optionID="19702" data-bindID="8675d88b-8af3-4d90-bc76-0dec1f668ac5" id="el_3720_5" data-elbindid="3374" data-max="999999" type="checkbox" value="8675d88b-8af3-4d90-bc76-0dec1f668ac5" name="el_3720" > 星期二 11:00am&nbsp; </label><label for="el_3720_6"><input data-label="星期二 2:00pm" data-value="" data-price="0.0000" data-optionID="19703" data-bindID="2b7b4e28-7fb7-45d7-8ca2-f722cd47d5fa" id="el_3720_6" data-elbindid="3374" data-max="999999" type="checkbox" value="2b7b4e28-7fb7-45d7-8ca2-f722cd47d5fa" name="el_3720" > 星期二 2:00pm&nbsp; </label><label for="el_3720_7"><input data-label="星期二 3:00pm" data-value="" data-price="0.0000" data-optionID="19704" data-bindID="55e64508-2c2f-4e5c-a769-40135803eeae" id="el_3720_7" data-elbindid="3374" data-max="999999" type="checkbox" value="55e64508-2c2f-4e5c-a769-40135803eeae" name="el_3720" > 星期二 3:00pm&nbsp; </label><label for="el_3720_8"><input data-label="星期三 9:00am" data-value="" data-price="0.0000" data-optionID="19705" data-bindID="34ba1bc9-04ad-470e-93d6-40c72e8a9212" id="el_3720_8" data-elbindid="3374" data-max="999999" type="checkbox" value="34ba1bc9-04ad-470e-93d6-40c72e8a9212" name="el_3720" > 星期三 9:00am&nbsp; </label><label for="el_3720_9"><input data-label="星期三 10:00am" data-value="" data-price="0.0000" data-optionID="19706" data-bindID="5bc28681-1611-4e49-a974-2bbdc932f26c" id="el_3720_9" data-elbindid="3374" data-max="999999" type="checkbox" value="5bc28681-1611-4e49-a974-2bbdc932f26c" name="el_3720" > 星期三 10:00am&nbsp; </label><label for="el_3720_10"><input data-label="星期三 11:00am" data-value="" data-price="0.0000" data-optionID="19707" data-bindID="bad40bc8-4550-4cfc-965a-9d7056761fcc" id="el_3720_10" data-elbindid="3374" data-max="999999" type="checkbox" value="bad40bc8-4550-4cfc-965a-9d7056761fcc" name="el_3720" > 星期三 11:00am&nbsp; </label><label for="el_3720_11"><input data-label="星期三 2:00pm" data-value="" data-price="0.0000" data-optionID="19708" data-bindID="45f2e917-d567-41ea-8949-51d7b561eda3" id="el_3720_11" data-elbindid="3374" data-max="999999" type="checkbox" value="45f2e917-d567-41ea-8949-51d7b561eda3" name="el_3720" > 星期三 2:00pm&nbsp; </label><label for="el_3720_12"><input data-label="星期三 3:00pm" data-value="" data-price="0.0000" data-optionID="19709" data-bindID="bea1b89f-5b94-4614-8293-0e4b5dbe32bd" id="el_3720_12" data-elbindid="3374" data-max="999999" type="checkbox" value="bea1b89f-5b94-4614-8293-0e4b5dbe32bd" name="el_3720" > 星期三 3:00pm&nbsp; </label><label for="el_3720_13"><input data-label="星期四 9:00am" data-value="" data-price="0.0000" data-optionID="19710" data-bindID="69fa7387-4c3b-483a-bfa2-b7620cf31885" id="el_3720_13" data-elbindid="3374" data-max="999999" type="checkbox" value="69fa7387-4c3b-483a-bfa2-b7620cf31885" name="el_3720" > 星期四 9:00am&nbsp; </label><label for="el_3720_14"><input data-label="星期四 10:00am" data-value="" data-price="0.0000" data-optionID="19711" data-bindID="41562914-ffe8-4f2e-8f12-0336c6ce50cb" id="el_3720_14" data-elbindid="3374" data-max="999999" type="checkbox" value="41562914-ffe8-4f2e-8f12-0336c6ce50cb" name="el_3720" > 星期四 10:00am&nbsp; </label><label for="el_3720_15"><input data-label="星期四 11:00am" data-value="" data-price="0.0000" data-optionID="19712" data-bindID="6745d7a0-4637-4bab-8754-c4ff8061a53a" id="el_3720_15" data-elbindid="3374" data-max="999999" type="checkbox" value="6745d7a0-4637-4bab-8754-c4ff8061a53a" name="el_3720" > 星期四 11:00am&nbsp; </label><label for="el_3720_16"><input data-label="星期四 2:00pm" data-value="" data-price="0.0000" data-optionID="19713" data-bindID="bd966872-6d38-4961-9069-d9cfcf865f62" id="el_3720_16" data-elbindid="3374" data-max="999999" type="checkbox" value="bd966872-6d38-4961-9069-d9cfcf865f62" name="el_3720" > 星期四 2:00pm&nbsp; </label><label for="el_3720_17"><input data-label="星期四 3:00pm" data-value="" data-price="0.0000" data-optionID="19714" data-bindID="4093ba2a-a958-47d4-a50e-a199e2ce3576" id="el_3720_17" data-elbindid="3374" data-max="999999" type="checkbox" value="4093ba2a-a958-47d4-a50e-a199e2ce3576" name="el_3720" > 星期四 3:00pm&nbsp; </label><label for="el_3720_18"><input data-label="星期五 9:00am" data-value="" data-price="0.0000" data-optionID="19715" data-bindID="99fa5189-eb9c-440d-8292-88f71347fbf9" id="el_3720_18" data-elbindid="3374" data-max="999999" type="checkbox" value="99fa5189-eb9c-440d-8292-88f71347fbf9" name="el_3720" > 星期五 9:00am&nbsp; </label><label for="el_3720_19"><input data-label="星期五 10:00am" data-value="" data-price="0.0000" data-optionID="19716" data-bindID="10e717cb-a993-470c-8bee-cb8ba0542629" id="el_3720_19" data-elbindid="3374" data-max="999999" type="checkbox" value="10e717cb-a993-470c-8bee-cb8ba0542629" name="el_3720" > 星期五 10:00am&nbsp; </label><label for="el_3720_20"><input data-label="星期五 11:00am" data-value="" data-price="0.0000" data-optionID="19717" data-bindID="f5543860-ec02-4736-90a1-68be4e479138" id="el_3720_20" data-elbindid="3374" data-max="999999" type="checkbox" value="f5543860-ec02-4736-90a1-68be4e479138" name="el_3720" > 星期五 11:00am&nbsp; </label><label for="el_3720_21"><input data-label="星期五 2:00pm" data-value="" data-price="0.0000" data-optionID="19718" data-bindID="3e3f51b7-adc8-495e-b8aa-0cf44117e1f0" id="el_3720_21" data-elbindid="3374" data-max="999999" type="checkbox" value="3e3f51b7-adc8-495e-b8aa-0cf44117e1f0" name="el_3720" > 星期五 2:00pm&nbsp; </label></fieldset></div><script type="text/javascript"> $j(document).ready(function() { setConditionalElement( "#elementContainer_3720", "#elementContainer_3721", '["f9604124-1f74-44a0-a745-2c9169276e68","7be81998-4d40-4931-b832-eac5b1ab1de9"]', true ); $j("#elementContainer_3720").addClass(""); }); </script></div></div><div class="elementRow"><div class="elementContainer field_3372 " id="elementContainer_3721"><div class="groupLabel required"><label for="el_3721" style="overflow: hidden;">预约参观校园*</label></div><div class="elementBody"><fieldset id="el_3721" class="fsValidate[required]"><label for="el_3721_0"><input data-label="二沙岛校区(幼儿园-5年级)" data-value="Checkbox" data-price="0.0000" data-optionID="19719" data-bindID="f9604124-1f74-44a0-a745-2c9169276e68" id="el_3721_0" data-elbindid="3372" data-max="999999" type="checkbox" value="f9604124-1f74-44a0-a745-2c9169276e68" name="el_3721" > 二沙岛校区(幼儿园-5年级)&nbsp; </label><label for="el_3721_1"><input data-label="科学城校区 (6-12年级)" data-value="" data-price="0.0000" data-optionID="19720" data-bindID="7be81998-4d40-4931-b832-eac5b1ab1de9" id="el_3721_1" data-elbindid="3372" data-max="999999" type="checkbox" value="7be81998-4d40-4931-b832-eac5b1ab1de9" name="el_3721" > 科学城校区 (6-12年级)&nbsp; </label></fieldset></div></div></div><div class="elementRow"><div class="elementContainer field_3375 " id="elementContainer_3722"><label for="el_3722" class="required">从什么地方了解AISG？ * </label><div class="elementBody"><select name="el_3722" id="el_3722" class="fsValidate[required]" data-elbindid="3375" data-max="999999"><option value="">Please Select&hellip;</option><option data-label="学校网站" data-value="Item One" data-price="0.0000" data-optionID="19721" data-bindID="5f5cec34-ef13-43c9-8b83-e98ad5627095" value="5f5cec34-ef13-43c9-8b83-e98ad5627095">学校网站</option><option data-label="Google 搜索" data-value="Item Two" data-price="0.0000" data-optionID="19722" data-bindID="983a5935-8d2d-4625-b87b-03f09d8a43fe" value="983a5935-8d2d-4625-b87b-03f09d8a43fe">Google 搜索</option><option data-label="网上广告" data-value="Item Three" data-price="0.0000" data-optionID="19723" data-bindID="739e0404-e44d-4c32-b8ab-8abd3ccbe2d2" value="739e0404-e44d-4c32-b8ab-8abd3ccbe2d2">网上广告</option><option data-label="社交媒体" data-value="" data-price="0.0000" data-optionID="19724" data-bindID="dc945603-6e08-46b2-a52e-73cecf37fe47" value="dc945603-6e08-46b2-a52e-73cecf37fe47">社交媒体</option><option data-label="电子邮件" data-value="" data-price="0.0000" data-optionID="19725" data-bindID="34122399-f389-4eb4-b6b0-a88e8f11bc46" value="34122399-f389-4eb4-b6b0-a88e8f11bc46">电子邮件</option><option data-label="印刷广告" data-value="" data-price="0.0000" data-optionID="19726" data-bindID="5143b648-4756-4aab-be27-685c58a322a6" value="5143b648-4756-4aab-be27-685c58a322a6">印刷广告</option><option data-label="广告牌" data-value="" data-price="0.0000" data-optionID="19727" data-bindID="27cea510-3387-40aa-ab73-2d273fdff3be" value="27cea510-3387-40aa-ab73-2d273fdff3be">广告牌</option><option data-label="口碑相传 (朋友，学校家长）" data-value="" data-price="0.0000" data-optionID="19728" data-bindID="50f2e9d2-106e-44a7-8688-644c3bc80704" value="50f2e9d2-106e-44a7-8688-644c3bc80704">口碑相传 (朋友，学校家长）</option><option data-label="学校招生部" data-value="" data-price="0.0000" data-optionID="19729" data-bindID="bab27b62-dabc-4e64-9edb-39ef43a074ae" value="bab27b62-dabc-4e64-9edb-39ef43a074ae">学校招生部</option><option data-label="其他" data-value="" data-price="0.0000" data-optionID="19730" data-bindID="5c1d4719-f4c1-46b7-ae81-fc5fadf675cc" value="5c1d4719-f4c1-46b7-ae81-fc5fadf675cc">其他</option></select></div><script type="text/javascript"> $j(document).ready(function() { setConditionalElement( "#elementContainer_3722", "#elementContainer_3721", '["f9604124-1f74-44a0-a745-2c9169276e68","7be81998-4d40-4931-b832-eac5b1ab1de9"]', true ); $j("#elementContainer_3722").addClass(""); }); </script></div></div></div> <div class="pageControls" style="border:0">
						
						<div class="pageBreak"><input type="button" name="prevPage_95" id="prevPage_95" class="prevPage" value="&lt; Back"> <span class="pagenum" id="pagenum_95"></span> <input type="button" class="nextPage" name="nextPage_95" id="nextPage_95" value="Next &gt;"> <input type="button" name="submitBtn" data-submitbuttontext="Send Request" value="Send Request" class="submitBtn" id="submitBtn_95"></div> </div>  <div class="hydraulics" data-thisIDSuffix=""><input type="text" name="hydraulics" id="hydraulics_95" value="" tabindex="-1" autocomplete="off"></div></div><input type="hidden" name="cmd_cf_forms" class="cmd_cf_forms" value=""><input type="hidden" name="formID" value="95"> <input type="hidden" name="submitID" value="0"> <input type="hidden" name="revisionNumber" value="4"><input type="hidden" name="requestMode" value="direct"><input type="hidden" class="hiddenElements" name="hiddenElements" value=""><input type="hidden" class="idSuffix" name="idSuffix" value=""><input type='hidden' name='formNonce' value='CA7621FD-C668-3479-3BC33001EF07D512'>
</form>

				</div>

		
</body>
</html>
