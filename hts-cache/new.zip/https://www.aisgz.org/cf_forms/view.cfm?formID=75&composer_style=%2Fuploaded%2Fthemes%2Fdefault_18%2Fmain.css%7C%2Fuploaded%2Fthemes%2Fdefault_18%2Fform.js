<!DOCTYPE html>
<html class="fsComposerFormEmbed">


<head><script type="text/javascript" src="/cf_scripts/scripts/cfform.js"></script>
<script type="text/javascript" src="/cf_scripts/scripts/masks.js"></script>

	<meta http-equiv="Content-type" content="text/html; charset=utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" >

	<script src="https://securejs.finalsite.com/190215/javascript/jQuery/jquery.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="https://securejs.finalsite.com/190215/javascript/jQuery/jquery-migrate-1.2.1.fs-modified.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="https://securejs.finalsite.com/190215/javascript/jQuery/jquery.ui.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="https://securejs.finalsite.com/190215/javascript/iFrameResizer/iframeResizer.contentWindow.min.js" type="text/javascript" charset="utf-8"></script>
	<script type="text/javascript" charset="utf-8">
		pathprefix = "../";
	</script>
   	<script src="https://securejs.finalsite.com/190215/javascript/fs_global.js" type="text/javascript" charset="utf-8"></script>
	<script type="text/javascript" charset="utf-8">
		$j = jQuery.noConflict();
		var siteDatemask = "md";
		var siteTimemask = "12";

		window.name = 'finalsiteadmin_aisgzorg';

		addHeight = 70;

		function popMedia(thevar) {
			var mh_url = pathprefix + "cf_media/popheight.cfm";

			mediaAction(thevar);
		}

		$j(document).ready(function(){
			$j('#leftFrame .btnLink').removeClass('on').each(function(i){
				if( $j(this).attr('href') == document.location.pathname + document.location.search ){
					$j(this).addClass('on');
				}
			});
		});

		siteurl = "https://www.aisgz.org";
		siteSSLurl = "https://www.aisgz.org";
		isEditor = true;
		basepath = '../';
		baseurl = "../";

	</script>
	<script src="scripts/adminview.js?decache=20111004064200" type="text/javascript" charset="utf-8"></script>

	
					<link rel="stylesheet" href="../uploaded/themes/default_18/main.css" type="text/css" media="screen" charset="utf-8">
				
					<script src="../uploaded/themes/default_18/form.js" type="text/javascript" charset="utf-8"></script>
				
	<link rel="stylesheet" href="https://www.aisgz.org/styles.cfm" type="text/css" media="screen" charset="utf-8">
<script src="https://securejs.finalsite.com/190215/javascript/jQuery/jquery-migrate-1.2.1.fs-modified.js?f=0" type="javascript"></script>

					<style type="text/css">
						.required{ color:#990033; font-weight:bold; }
					</style>

					<link rel="stylesheet" href="https://www.aisgz.org/cf_forms/scripts/formPlugin.css?decache=CA6FD000-B496-6519-59B38649C82A1ABD" type="text/css" charset="utf-8">

					<link rel="stylesheet" href="https://securejs.finalsite.com/190215/javascript/jQuery/themes/base/ui.all.css?decache=190215" type="text/css" title="no title" charset="utf-8">
					<link rel="stylesheet" href="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/validationEngine.jquery.css?decache=190215" type="text/css" charset="utf-8" />
					<link rel="stylesheet" href="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/fsNumberSpinner/jquery.fsNumberSpinner.css?decache=190215" type="text/css" charset="utf-8" />

					
					

					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/jquery.ui.min.js?decache=190215" type="text/javascript"></script>

					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/jquery.json.js?decache=190215" type="text/javascript"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/jquery.base64.js?decache=190215" type="text/javascript"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/jquery.finalsiteValidator.min.js?decache=190215" type="text/javascript" charset="utf-8"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/jquery.uuid.min.js?decache=190215" type="text/javascript" charset="utf-8"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/jquery.finalsiteSumInputs.min.js?decache=190215" type="text/javascript" charset="utf-8"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/jquery.scrollTo-1.4.2-min.js?decache=190215" type="text/javascript"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/autonumeric/autoNumeric.min.js?decache=190215" type="text/javascript"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/jquery.autoLoader.js?decache=190215" type="text/javascript"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/fsNumberSpinner/jquery.fsNumberSpinner.min.js?decache=190215" type="text/javascript"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/fsNumberBox/jquery.fsNumberBox.min.js?decache=190215" type="text/javascript"></script>

					
					

					<script type="text/javascript" charset="utf-8">
						// <![CDATA[

						// we need to count how many forms require a warn before unload
						// for example, banners do not
						var warnBeforeUnloadCount = 0;

						// ]]>
					</script>

					<script type="text/javascript" charset="utf-8">
						var jsPath = "https://www.aisgz.org/";
						var formPluginRequestMode = "direct";

						// set our options for this form
						$j(document).ready(function() {
							

							$j("#form_75").data( "formOptions", {"submitButtonText":"Send","formWidth":950,"expiredFormText":"This form has expired.","emailAddressAlias":"donotreply@aisgz.org","maxFormWidth":1037,"defaultLabelPosition":"top","defaultTipPosition":"below"} );
							
						} );

						// we will keep extending this object
						fs = {};
						isAdmin = false;
						// for date conditionals
						nowTS = 201905171620;
					</script>
					
						
						<script src="https://www.aisgz.org/cf_forms/scripts/formPlugin.min.js?decache=CA6FD000-B496-6519-59B38649C82A1ABD" type="text/javascript" charset="utf-8"></script>
					
					<script type="text/javascript" charset="utf-8">
						// <![CDATA[
						warnBeforeUnloadCount++;
						// ]]>
					</script>
				
				<script type="text/javascript" charset="utf-8">
					isQuiz = false;
					
				</script>
			<script type="text/javascript">
<!--
    _CF_checkform_75 = function(_CF_this)
    {
        //reset on submit
        _CF_error_exists = false;
        _CF_error_messages = new Array();
        _CF_error_fields = new Object();
        _CF_FirstErrorField = null;


        //display error messages and return success
        if( _CF_error_exists )
        {
            if( _CF_error_messages.length > 0 )
            {
                // show alert() message
                _CF_onErrorAlert(_CF_error_messages);
                // set focus to first form error, if the field supports js focus().
                if( _CF_this[_CF_FirstErrorField].type == "text" )
                { _CF_this[_CF_FirstErrorField].focus(); }

            }
            return false;
        }else {
            return true;
        }
    }
//-->
</script>
</head>


<body>

	

	
	<a name="formAnchor_75"></a>

	

				<div class="subGroup">

					
					<script type="text/javascript">
						cp = {};
						fs = $j.extend( fs, {"revisionNumber":0,"REQUESTMODE":"direct","formID":0,"submissionExists":0,"submitID":0,"IFRAMEMODE":false,"CMD_CF_FORMS":"","HIDDENELEMENTS":"","ISFRAMED":false} );
						idSuffix = "";
						hasReg = false;
						rg = {};
						wlClaim = [];
						wlClaimBindIDs = [];
						regKey = "";
						ro = {};
						adminBypass = false;
						aSess = false;

						
						
					</script>

					
					<form name="form_75" id="form_75" action="/cf_forms/view.cfm?composer_style=%252Fuploaded%252Fthemes%252Fdefault%5F18%252Fmain%2Ecss%257C%252Fuploaded%252Fthemes%252Fdefault%5F18%252Fform%2Ejs%2C%2Fuploaded%2Fthemes%2Fdefault%5F18%2Fmain%2Ecss%7C%2Fuploaded%2Fthemes%2Fdefault%5F18%2Fform%2Ejs&CSB=off&adminBypass=false&verbose=0&formID=75#formAnchor_75" method="post" class="cf_form disableEnter" enctype="multipart/form-data" onsubmit="return _CF_checkform_75(this)"><div class="mainGroupSub targetForm" id="targetForm_75"><div class="formPage" id="formPage_75_1"><div class="elementRow"><div class="elementContainer field_3624 " id="elementContainer_4149"><div class="textblock "><h4>1. Donor Information</h4></div></div></div><div class="elementRow"><div class="elementContainer field_1923 " id="elementContainer_4150"><label for="el_4150" class="required">Affiliation* </label><div class="elementBody"><select name="el_4150" id="el_4150" class="fsValidate[required]" data-elbindid="1923" data-max="999999"><option value="">Please Select&hellip;</option><option data-label="Current parent" data-value="Item Two" data-price="0.0000" data-optionID="21392" data-bindID="11fad826-92f9-4e1c-a623-dedcdd3a76dc" value="11fad826-92f9-4e1c-a623-dedcdd3a76dc">Current parent</option><option data-label="Alumni Parent" data-value="Item Three" data-price="0.0000" data-optionID="21393" data-bindID="1ec04d6f-7199-43a1-a424-52867e8cfa50" value="1ec04d6f-7199-43a1-a424-52867e8cfa50">Alumni Parent</option><option data-label="Grandparent" data-value="" data-price="0.0000" data-optionID="21394" data-bindID="e759d0d0-228e-42ae-aaaa-6e14c4a43106" value="e759d0d0-228e-42ae-aaaa-6e14c4a43106">Grandparent</option><option data-label="Faculty/Staff" data-value="" data-price="0.0000" data-optionID="21395" data-bindID="570ac402-014d-466a-8690-06aeededf751" value="570ac402-014d-466a-8690-06aeededf751">Faculty/Staff</option><option data-label="Alumni" data-value="" data-price="0.0000" data-optionID="21396" data-bindID="e168a851-49ae-4699-b986-eb118ee46fb9" value="e168a851-49ae-4699-b986-eb118ee46fb9">Alumni</option></select></div></div></div><div class="elementRow"><div class="elementColumn" style="width: 47em;"><div class="elementContainer field_1914 " id="elementContainer_4151"><label for="el_4151" class="required">Name* </label><div class="elementBody"><input type="text" name="el_4151" data-elbindid="1914" data-prefill="NO" data-prefillDataField="NO" id="el_4151" value="" size="50" maxlength="255" class="fsValidate[required]" /></div></div></div><div class="elementColumn" style="width: 47.27em;"><div class="elementContainer field_1915 " id="elementContainer_4152"><label for="el_4152">Student Name (if applicable) </label><div class="elementBody"><input type="text" name="el_4152" data-elbindid="1915" data-prefill="false" data-prefillDataField="false" id="el_4152" value="" size="50" maxlength="255" /></div></div></div></div><div class="elementRow"><div class="elementContainer field_3628 " id="elementContainer_4153"><label for="el_4153">Student Class (if applicable) </label><div class="elementBody"><input type="text" name="el_4153" data-elbindid="3628" data-prefill="false" data-prefillDataField="false" id="el_4153" value="" size="20" maxlength="255" /></div></div></div><div class="elementRow"><div class="elementColumn" style="width: 47em;"><div class="elementContainer field_1916 " id="elementContainer_4154"><label for="el_4154" class="required">Email * </label><div class="elementBody"><input type="text" name="el_4154" data-elbindid="1916" data-prefill="NO" data-prefillDataField="Email" id="el_4154" value="" size="50" maxlength="255" class="fsValidate[required,email]" /></div></div></div><div class="elementColumn" style="width: 47.27em;"><div class="elementContainer field_1917 " id="elementContainer_4155"><label for="el_4155" class="required">Mobile* </label><div class="elementBody"><input type="text" name="el_4155" data-elbindid="1917" data-prefill="NO" data-prefillDataField="NO" id="el_4155" value="" size="50" maxlength="255" class="fsValidate[required]" /></div></div></div></div><div class="elementRow"><div class="elementContainer field_3642 " id="elementContainer_4156"><div class="textblock "><h4>2. Pledge Information</h4></div></div></div><div class="elementRow"><div class="elementContainer field_3643 " id="elementContainer_4157"><div class="groupLabel required"><label for="el_4157" style="overflow: hidden;">I/we pledge​ the amount below to the Annual Fund.​*</label></div><div class="elementBody"><fieldset id="el_4157" class="fsValidate[required]"><label for="el_4157_0" class="horizontal"><input data-label="RMB1,000" data-value="" data-price="0.0000" data-optionID="21397" data-bindID="9937f543-8d3e-463f-b808-f15091fb4481" id="el_4157_0" data-elbindid="3643" data-max="999999" type="checkbox" value="9937f543-8d3e-463f-b808-f15091fb4481" name="el_4157" > RMB1,000&nbsp; </label><label for="el_4157_1" class="horizontal"><input data-label="RMB2,000" data-value="" data-price="0.0000" data-optionID="21398" data-bindID="4e23cf06-d6dd-4fd8-a6fa-390640cbda7f" id="el_4157_1" data-elbindid="3643" data-max="999999" type="checkbox" value="4e23cf06-d6dd-4fd8-a6fa-390640cbda7f" name="el_4157" > RMB2,000&nbsp; </label><label for="el_4157_2" class="horizontal"><input data-label="RMB5,000" data-value="" data-price="0.0000" data-optionID="21399" data-bindID="dd12e754-288a-499c-b3b4-5634c323d8fe" id="el_4157_2" data-elbindid="3643" data-max="999999" type="checkbox" value="dd12e754-288a-499c-b3b4-5634c323d8fe" name="el_4157" > RMB5,000&nbsp; </label><label for="el_4157_3" class="horizontal"><input data-label="RMB10,000" data-value="" data-price="0.0000" data-optionID="21400" data-bindID="07f1277d-25f1-4ae1-83a1-e512e5374549" id="el_4157_3" data-elbindid="3643" data-max="999999" type="checkbox" value="07f1277d-25f1-4ae1-83a1-e512e5374549" name="el_4157" > RMB10,000&nbsp; </label><label for="el_4157_4" class="horizontal"><input data-label="RMB20,000" data-value="" data-price="0.0000" data-optionID="21401" data-bindID="d19863b2-e1e8-4f5d-918f-b765c8ca0420" id="el_4157_4" data-elbindid="3643" data-max="999999" type="checkbox" value="d19863b2-e1e8-4f5d-918f-b765c8ca0420" name="el_4157" > RMB20,000&nbsp; </label><label for="el_4157_5" class="horizontal"><input data-label="RMB50,000" data-value="" data-price="0.0000" data-optionID="21402" data-bindID="5a561dec-fb1d-48fe-804c-b2cc3a224209" id="el_4157_5" data-elbindid="3643" data-max="999999" type="checkbox" value="5a561dec-fb1d-48fe-804c-b2cc3a224209" name="el_4157" > RMB50,000&nbsp; </label><label for="el_4157_6" class="horizontal"><input data-label="RMB100,000" data-value="" data-price="0.0000" data-optionID="21403" data-bindID="f019a05d-ad93-4a29-ae87-f591bc735196" id="el_4157_6" data-elbindid="3643" data-max="999999" type="checkbox" value="f019a05d-ad93-4a29-ae87-f591bc735196" name="el_4157" > RMB100,000&nbsp; </label><label for="el_4157_7" class="horizontal"><input data-label="Other amount" data-value="" data-price="0.0000" data-optionID="21404" data-bindID="f1f93540-5407-4623-a3ca-1c89c72a1146" id="el_4157_7" data-elbindid="3643" data-max="999999" type="checkbox" value="f1f93540-5407-4623-a3ca-1c89c72a1146" name="el_4157" > Other amount&nbsp; </label></fieldset></div></div></div><div class="elementRow"><div class="elementContainer field_3644 " id="elementContainer_4158"><label for="el_4158">other amount </label><div class="elementBody"><input type="text" name="el_4158" data-elbindid="3644" data-prefill="false" data-prefillDataField="false" id="el_4158" value="" size="40" maxlength="255" /></div></div></div><div class="elementRow"><div class="elementContainer field_3645 " id="elementContainer_4159"><div class="groupLabel"><label for="el_4159" style="overflow: hidden;">Donation Recognition</label></div><div class="elementBody"><fieldset id="el_4159"><label for="el_4159_0" class="horizontal"><input data-label="This gift is anonymous." data-value="" data-price="0.0000" data-optionID="21405" data-bindID="3bf8f9fb-4cc1-4664-9806-f03c49a2f77f" id="el_4159_0" data-elbindid="3645" data-max="999999" type="checkbox" value="3bf8f9fb-4cc1-4664-9806-f03c49a2f77f" name="el_4159" > This gift is anonymous.&nbsp; </label></fieldset></div></div></div><div class="elementRow"><div class="elementContainer field_3646 " id="elementContainer_4160"><label for="el_4160">This gift is in honor/memory of </label><div class="elementBody"><input type="text" name="el_4160" data-elbindid="3646" data-prefill="false" data-prefillDataField="false" id="el_4160" value="" size="40" maxlength="255" /></div></div></div><div class="elementRow"><div class="elementContainer field_3648 " id="elementContainer_4161"><div class="groupLabel"><label for="el_4161" style="overflow: hidden;">Ways to Give</label></div><div class="elementBody"><fieldset id="el_4161"><label for="el_4161_0" class="horizontal"><input data-label="WeChat Pay" data-value="Checkbox" data-price="0.0000" data-optionID="21406" data-bindID="28b50839-d1eb-4605-b468-3cd04c7f6df0" id="el_4161_0" data-elbindid="3648" data-max="999999" type="checkbox" value="28b50839-d1eb-4605-b468-3cd04c7f6df0" name="el_4161" > WeChat Pay&nbsp; </label><label for="el_4161_1" class="horizontal"><input data-label="Bank Transfer" data-value="" data-price="0.0000" data-optionID="21407" data-bindID="bc102999-9fb7-4056-acae-b5004e173795" id="el_4161_1" data-elbindid="3648" data-max="999999" type="checkbox" value="bc102999-9fb7-4056-acae-b5004e173795" name="el_4161" > Bank Transfer&nbsp; </label><label for="el_4161_2" class="horizontal"><input data-label="Cash/Credit Card" data-value="" data-price="0.0000" data-optionID="21408" data-bindID="9631015e-152d-4999-8162-f89c76961107" id="el_4161_2" data-elbindid="3648" data-max="999999" type="checkbox" value="9631015e-152d-4999-8162-f89c76961107" name="el_4161" > Cash/Credit Card&nbsp; </label></fieldset></div></div></div><div class="elementRow"><div class="elementContainer field_3647 " id="elementContainer_4162"><div class="textblock "><h4>3. Annual Fund Project Recommendation</h4></div></div></div><div class="elementRow"><div class="elementContainer field_3649 " id="elementContainer_4163"><textarea name="el_4163" id="el_4163" data-prefill="false" data-prefillDataField="false" rows="4" cols="32"></textarea></div></div><div class="elementRow"><div class="elementContainer field_2818 " id="elementContainer_4164"><div class="textblock "><p class="p1">For more assistance or more information about making a major gift, please contact the Advancement and Communications Office.</p><p class="p1"><br></p><p class="p1">Zoe Timms</p><p class="p1">Director of Advancement and Communications</p><p class="p1">American International School of Guangzhou</p><p class="p1">Email: ztimms@aisgz.org</p><p class="p1">T: +8620 3213 5555 | Ext: 5415</p><p class="p2"><br></p><p class="p1">Ava Xing</p><p class="p1">Deputy Director of Advancement and Communications</p><p class="p1">American International School of Guangzhou</p><p class="p1">Email: axing@aisgz.org</p><p class="p1">T: +8620 3213 5555 | Ext: 5420</p></div></div></div></div> <div id="pageControls_75" class="pageControls">
									
									<div class="userConfirmation">
										<label class="required"><input type="checkbox" id="userConfirmationToggle_75" name="userConfirmationToggle" class="userConfirmationToggle" value="1" checked disabled>Please send a confirmation email to the address below*:</label><br>
										<input type="text" name="userConfirmationEmail" id="userConfirmationEmail_75" value="my email address" class="userConfirmationEmail fsValidate[required,email]">
									</div>
								</div>
							

							<div class="pageControls" style="border:0">
						
						<div class="pageBreak"><input type="button" name="prevPage_75" id="prevPage_75" class="prevPage" value="&lt; Back"> <span class="pagenum" id="pagenum_75"></span> <input type="button" class="nextPage" name="nextPage_75" id="nextPage_75" value="Next &gt;"> <input type="button" name="submitBtn" data-submitbuttontext="Send" value="Send" class="submitBtn" id="submitBtn_75"></div> </div>  <div class="hydraulics" data-thisIDSuffix=""><input type="text" name="hydraulics" id="hydraulics_75" value="" tabindex="-1" autocomplete="off"></div></div><input type="hidden" name="cmd_cf_forms" class="cmd_cf_forms" value=""><input type="hidden" name="formID" value="75"> <input type="hidden" name="submitID" value="0"> <input type="hidden" name="revisionNumber" value="41"><input type="hidden" name="requestMode" value="direct"><input type="hidden" class="hiddenElements" name="hiddenElements" value=""><input type="hidden" class="idSuffix" name="idSuffix" value=""><input type='hidden' name='formNonce' value='CA6FD222-BC14-B966-6642C1697DD1025F'>
</form>

				</div>

		
</body>
</html>
