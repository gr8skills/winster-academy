<!DOCTYPE html>
<html class="fsComposerFormEmbed">


<head><script type="text/javascript" src="/cf_scripts/scripts/cfform.js"></script>
<script type="text/javascript" src="/cf_scripts/scripts/masks.js"></script>

	<meta http-equiv="Content-type" content="text/html; charset=utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" >

	<script src="https://securejs.finalsite.com/190215/javascript/jQuery/jquery.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="https://securejs.finalsite.com/190215/javascript/jQuery/jquery-migrate-1.2.1.fs-modified.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="https://securejs.finalsite.com/190215/javascript/jQuery/jquery.ui.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="https://securejs.finalsite.com/190215/javascript/iFrameResizer/iframeResizer.contentWindow.min.js" type="text/javascript" charset="utf-8"></script>
	<script type="text/javascript" charset="utf-8">
		pathprefix = "../";
	</script>
   	<script src="https://securejs.finalsite.com/190215/javascript/fs_global.js" type="text/javascript" charset="utf-8"></script>
	<script type="text/javascript" charset="utf-8">
		$j = jQuery.noConflict();
		var siteDatemask = "md";
		var siteTimemask = "12";

		window.name = 'finalsiteadmin_aisgzorg';

		addHeight = 70;

		function popMedia(thevar) {
			var mh_url = pathprefix + "cf_media/popheight.cfm";

			mediaAction(thevar);
		}

		$j(document).ready(function(){
			$j('#leftFrame .btnLink').removeClass('on').each(function(i){
				if( $j(this).attr('href') == document.location.pathname + document.location.search ){
					$j(this).addClass('on');
				}
			});
		});

		siteurl = "https://www.aisgz.org";
		siteSSLurl = "https://www.aisgz.org";
		isEditor = true;
		basepath = '../';
		baseurl = "../";

	</script>
	<script src="scripts/adminview.js?decache=20111004064200" type="text/javascript" charset="utf-8"></script>

	
					<link rel="stylesheet" href="../uploaded/themes/default_18/main.css" type="text/css" media="screen" charset="utf-8">
				
					<script src="../uploaded/themes/default_18/form.js" type="text/javascript" charset="utf-8"></script>
				
	<link rel="stylesheet" href="https://www.aisgz.org/styles.cfm" type="text/css" media="screen" charset="utf-8">
<script src="https://securejs.finalsite.com/190215/javascript/jQuery/jquery-migrate-1.2.1.fs-modified.js?f=0" type="javascript"></script>

					<style type="text/css">
						.required{ color:#990033; font-weight:bold; }
					</style>

					<link rel="stylesheet" href="https://www.aisgz.org/cf_forms/scripts/formPlugin.css?decache=CA6DD3EF-DF91-F9D4-9D99E5C9530EA5A4" type="text/css" charset="utf-8">

					<link rel="stylesheet" href="https://securejs.finalsite.com/190215/javascript/jQuery/themes/base/ui.all.css?decache=190215" type="text/css" title="no title" charset="utf-8">
					<link rel="stylesheet" href="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/validationEngine.jquery.css?decache=190215" type="text/css" charset="utf-8" />
					<link rel="stylesheet" href="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/fsNumberSpinner/jquery.fsNumberSpinner.css?decache=190215" type="text/css" charset="utf-8" />

					
					

					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/jquery.ui.min.js?decache=190215" type="text/javascript"></script>

					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/jquery.json.js?decache=190215" type="text/javascript"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/jquery.base64.js?decache=190215" type="text/javascript"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/jquery.finalsiteValidator.min.js?decache=190215" type="text/javascript" charset="utf-8"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/jquery.uuid.min.js?decache=190215" type="text/javascript" charset="utf-8"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/jquery.finalsiteSumInputs.min.js?decache=190215" type="text/javascript" charset="utf-8"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/jquery.scrollTo-1.4.2-min.js?decache=190215" type="text/javascript"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/autonumeric/autoNumeric.min.js?decache=190215" type="text/javascript"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/jquery.autoLoader.js?decache=190215" type="text/javascript"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/fsNumberSpinner/jquery.fsNumberSpinner.min.js?decache=190215" type="text/javascript"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/fsNumberBox/jquery.fsNumberBox.min.js?decache=190215" type="text/javascript"></script>

					
					

					<script type="text/javascript" charset="utf-8">
						// <![CDATA[

						// we need to count how many forms require a warn before unload
						// for example, banners do not
						var warnBeforeUnloadCount = 0;

						// ]]>
					</script>

					<script type="text/javascript" charset="utf-8">
						var jsPath = "https://www.aisgz.org/";
						var formPluginRequestMode = "direct";

						// set our options for this form
						$j(document).ready(function() {
							

							$j("#form_90").data( "formOptions", {"submitButtonText":"Send","formWidth":950,"expiredFormText":"This form has expired.","maxFormWidth":938,"defaultLabelPosition":"top","defaultTipPosition":"below"} );
							
						} );

						// we will keep extending this object
						fs = {};
						isAdmin = false;
						// for date conditionals
						nowTS = 201905171619;
					</script>
					
						
						<script src="https://www.aisgz.org/cf_forms/scripts/formPlugin.min.js?decache=CA6DD3EF-DF91-F9D4-9D99E5C9530EA5A4" type="text/javascript" charset="utf-8"></script>
					
					<script type="text/javascript" charset="utf-8">
						// <![CDATA[
						warnBeforeUnloadCount++;
						// ]]>
					</script>
				
				<script type="text/javascript" charset="utf-8">
					isQuiz = false;
					
				</script>
			<script type="text/javascript">
<!--
    _CF_checkform_90 = function(_CF_this)
    {
        //reset on submit
        _CF_error_exists = false;
        _CF_error_messages = new Array();
        _CF_error_fields = new Object();
        _CF_FirstErrorField = null;


        //display error messages and return success
        if( _CF_error_exists )
        {
            if( _CF_error_messages.length > 0 )
            {
                // show alert() message
                _CF_onErrorAlert(_CF_error_messages);
                // set focus to first form error, if the field supports js focus().
                if( _CF_this[_CF_FirstErrorField].type == "text" )
                { _CF_this[_CF_FirstErrorField].focus(); }

            }
            return false;
        }else {
            return true;
        }
    }
//-->
</script>

                    <script>var w=window;if(w.performance||w.mozPerformance||w.msPerformance||w.webkitPerformance){var d=document;AKSB=w.AKSB||{},AKSB.q=AKSB.q||[],AKSB.mark=AKSB.mark||function(e,_){AKSB.q.push(["mark",e,_||(new Date).getTime()])},AKSB.measure=AKSB.measure||function(e,_,t){AKSB.q.push(["measure",e,_,t||(new Date).getTime()])},AKSB.done=AKSB.done||function(e){AKSB.q.push(["done",e])},AKSB.mark("firstbyte",(new Date).getTime()),AKSB.prof={custid:"142953",ustr:"",originlat:"0",clientrtt:"239",ghostip:"79.140.94.251",ipv6:false,pct:"10",clientip:"129.18.140.70",requestid:"a13816b",region:"13956",protocol:"",blver:14,akM:"a",akN:"ae",akTT:"O",akTX:"1",akTI:"a13816b",ai:"477723",ra:"false",pmgn:"",pmgi:"",pmp:"",qc:""},function(e){var _=d.createElement("script");_.async="async",_.src=e;var t=d.getElementsByTagName("script"),t=t[t.length-1];t.parentNode.insertBefore(_,t)}(("https:"===d.location.protocol?"https:":"http:")+"//ds-aksb-a.akamaihd.net/aksb.min.js")}</script>
                    </head>


<body>

	

	
	<a name="formAnchor_90"></a>

	

				<div class="subGroup">

					
					<script type="text/javascript">
						cp = {};
						fs = $j.extend( fs, {"CMD_CF_FORMS":"","submitID":0,"REQUESTMODE":"direct","HIDDENELEMENTS":"","formID":0,"revisionNumber":0,"ISFRAMED":false,"IFRAMEMODE":false,"submissionExists":0} );
						idSuffix = "";
						hasReg = false;
						rg = {};
						wlClaim = [];
						wlClaimBindIDs = [];
						regKey = "";
						ro = {};
						adminBypass = false;
						aSess = false;

						
						
					</script>

					
					<form name="form_90" id="form_90" action="/cf_forms/view.cfm?composer_style=%252Fuploaded%252Fthemes%252Fdefault%5F18%252Fmain%2Ecss%257C%252Fuploaded%252Fthemes%252Fdefault%5F18%252Fform%2Ejs%2C%2Fuploaded%2Fthemes%2Fdefault%5F18%2Fmain%2Ecss%7C%2Fuploaded%2Fthemes%2Fdefault%5F18%2Fform%2Ejs&CSB=off&adminBypass=false&verbose=0&formID=90#formAnchor_90" method="post" class="cf_form disableEnter" enctype="multipart/form-data" onsubmit="return _CF_checkform_90(this)"><div class="mainGroupSub targetForm" id="targetForm_90"><div class="formPage" id="formPage_90_1"><div class="elementRow"><div class="elementContainer field_2853 " id="elementContainer_2859"><label for="el_2859" class="required">First Name* </label><div class="elementBody"><input type="text" name="el_2859" data-elbindid="2853" data-prefill="NO" data-prefillDataField="NO" id="el_2859" value="" size="50" maxlength="255" class="fsValidate[required]" /></div></div></div><div class="elementRow"><div class="elementContainer field_2854 " id="elementContainer_2860"><label for="el_2860" class="required">Last Name* </label><div class="elementBody"><input type="text" name="el_2860" data-elbindid="2854" data-prefill="NO" data-prefillDataField="NO" id="el_2860" value="" size="50" maxlength="255" class="fsValidate[required]" /></div></div></div><div class="elementRow"><div class="elementContainer field_2855 " id="elementContainer_2861"><label for="el_2861" class="required">Email * </label><div class="elementBody"><input type="text" name="el_2861" data-elbindid="2855" data-prefill="NO" data-prefillDataField="Email" id="el_2861" value="" size="50" maxlength="255" class="fsValidate[required,email]" /></div></div></div><div class="elementRow"><div class="elementContainer field_2856 " id="elementContainer_2862"><label for="el_2862" class="required">Class Year* </label><div class="elementBody"><select name="el_2862" id="el_2862" class="fsValidate[required]" data-elbindid="2856" data-max="999999"><option value="">Please Select&hellip;</option><option data-label="2018" data-value="Item One" data-price="0.0000" data-optionID="8191" data-bindID="faeaed0d-0454-46df-a6a7-7a7bea88ff65" value="faeaed0d-0454-46df-a6a7-7a7bea88ff65">2018</option><option data-label="2017" data-value="Item Two" data-price="0.0000" data-optionID="8192" data-bindID="0f73a4f6-73f9-4cd4-94f0-ed689c858052" value="0f73a4f6-73f9-4cd4-94f0-ed689c858052">2017</option><option data-label="2016" data-value="Item Three" data-price="0.0000" data-optionID="8193" data-bindID="3c4a5b11-60fb-4826-a4cf-a50cd43e3276" value="3c4a5b11-60fb-4826-a4cf-a50cd43e3276">2016</option><option data-label="2015" data-value="" data-price="0.0000" data-optionID="8194" data-bindID="b35fffdf-95a5-4fde-b519-6ea3f73eef0a" value="b35fffdf-95a5-4fde-b519-6ea3f73eef0a">2015</option><option data-label="2014" data-value="" data-price="0.0000" data-optionID="8195" data-bindID="2dcd32b8-782d-42a4-b733-91a1edb973a0" value="2dcd32b8-782d-42a4-b733-91a1edb973a0">2014</option><option data-label="2013" data-value="" data-price="0.0000" data-optionID="8196" data-bindID="eb103153-2ab5-45a1-86e2-479667e3e64d" value="eb103153-2ab5-45a1-86e2-479667e3e64d">2013</option><option data-label="2012" data-value="" data-price="0.0000" data-optionID="8197" data-bindID="07a770e7-00b1-4011-b05a-a7aa1cf9101f" value="07a770e7-00b1-4011-b05a-a7aa1cf9101f">2012</option><option data-label="2011" data-value="" data-price="0.0000" data-optionID="8198" data-bindID="86b10991-51e1-4fc7-9fce-08646d9189d5" value="86b10991-51e1-4fc7-9fce-08646d9189d5">2011</option><option data-label="2010" data-value="" data-price="0.0000" data-optionID="8199" data-bindID="0ca6b549-c926-43af-b500-6833fa5100f7" value="0ca6b549-c926-43af-b500-6833fa5100f7">2010</option><option data-label="2009" data-value="" data-price="0.0000" data-optionID="8200" data-bindID="4be2b9b9-a008-49f6-a0d9-01c0dad08bc2" value="4be2b9b9-a008-49f6-a0d9-01c0dad08bc2">2009</option><option data-label="2008" data-value="" data-price="0.0000" data-optionID="8201" data-bindID="0d2259d0-b358-49c9-aa76-8355a82bc0a1" value="0d2259d0-b358-49c9-aa76-8355a82bc0a1">2008</option><option data-label="2007" data-value="" data-price="0.0000" data-optionID="8202" data-bindID="18ec5121-9c92-4126-bfdd-9b78257a285a" value="18ec5121-9c92-4126-bfdd-9b78257a285a">2007</option><option data-label="2006" data-value="" data-price="0.0000" data-optionID="8203" data-bindID="edad48ce-a799-4e1b-9e01-39b086f199fb" value="edad48ce-a799-4e1b-9e01-39b086f199fb">2006</option><option data-label="2005" data-value="" data-price="0.0000" data-optionID="8204" data-bindID="1e18fe62-da96-4213-b485-7e2905287ee6" value="1e18fe62-da96-4213-b485-7e2905287ee6">2005</option><option data-label="2004" data-value="" data-price="0.0000" data-optionID="8205" data-bindID="bbe55b5d-d7fd-45ca-a7f9-a7fbb43cbacf" value="bbe55b5d-d7fd-45ca-a7f9-a7fbb43cbacf">2004</option><option data-label="2003" data-value="" data-price="0.0000" data-optionID="8206" data-bindID="4ce82d24-de74-40b3-a0d5-9510eda68406" value="4ce82d24-de74-40b3-a0d5-9510eda68406">2003</option><option data-label="2002" data-value="" data-price="0.0000" data-optionID="8207" data-bindID="8e64120d-dc96-4817-98f9-f522d5e83cc1" value="8e64120d-dc96-4817-98f9-f522d5e83cc1">2002</option><option data-label="2001" data-value="" data-price="0.0000" data-optionID="8208" data-bindID="ca929efd-01f1-4e06-a642-b113b7ddd9a7" value="ca929efd-01f1-4e06-a642-b113b7ddd9a7">2001</option><option data-label="2000" data-value="" data-price="0.0000" data-optionID="8209" data-bindID="1b2390a6-1413-4115-a4f3-1dd26a39da6a" value="1b2390a6-1413-4115-a4f3-1dd26a39da6a">2000</option><option data-label="1999" data-value="" data-price="0.0000" data-optionID="8210" data-bindID="95a830b4-9bab-47ce-b701-0f0e699b0677" value="95a830b4-9bab-47ce-b701-0f0e699b0677">1999</option><option data-label="1998" data-value="" data-price="0.0000" data-optionID="8211" data-bindID="684c62b2-67ef-4156-819c-5ba5e015b440" value="684c62b2-67ef-4156-819c-5ba5e015b440">1998</option><option data-label="1997" data-value="" data-price="0.0000" data-optionID="8212" data-bindID="be9ea1c2-8ae6-4370-a7ac-5df87aca0853" value="be9ea1c2-8ae6-4370-a7ac-5df87aca0853">1997</option><option data-label="1996" data-value="" data-price="0.0000" data-optionID="8213" data-bindID="d61dfeaa-4c16-42ad-b5bf-ebc1e575f841" value="d61dfeaa-4c16-42ad-b5bf-ebc1e575f841">1996</option><option data-label="1995" data-value="" data-price="0.0000" data-optionID="8214" data-bindID="2b6c1299-7e91-46e5-aeb5-02fbddc2e66f" value="2b6c1299-7e91-46e5-aeb5-02fbddc2e66f">1995</option><option data-label="1994" data-value="" data-price="0.0000" data-optionID="8215" data-bindID="e74e565c-ac1b-4e5f-b647-7eb640c59e8e" value="e74e565c-ac1b-4e5f-b647-7eb640c59e8e">1994</option><option data-label="1993" data-value="" data-price="0.0000" data-optionID="8216" data-bindID="47405698-5903-4493-a6e1-14040d0272e3" value="47405698-5903-4493-a6e1-14040d0272e3">1993</option><option data-label="1992" data-value="" data-price="0.0000" data-optionID="8217" data-bindID="f7d4864c-5aad-430a-b07d-5ad2344618d0" value="f7d4864c-5aad-430a-b07d-5ad2344618d0">1992</option><option data-label="1991" data-value="" data-price="0.0000" data-optionID="8218" data-bindID="ab83cbed-a58a-4ac3-b05d-6fb79d76cac8" value="ab83cbed-a58a-4ac3-b05d-6fb79d76cac8">1991</option><option data-label="1990" data-value="" data-price="0.0000" data-optionID="8219" data-bindID="9c9ecd76-b697-453a-ba9b-8c929611e9b8" value="9c9ecd76-b697-453a-ba9b-8c929611e9b8">1990</option><option data-label="1989" data-value="" data-price="0.0000" data-optionID="8220" data-bindID="d2afaa8c-e6d9-46c9-bec7-d04303a7962d" value="d2afaa8c-e6d9-46c9-bec7-d04303a7962d">1989</option><option data-label="1988" data-value="" data-price="0.0000" data-optionID="8221" data-bindID="949a75ea-341e-4ec8-9b6c-11b21158bd32" value="949a75ea-341e-4ec8-9b6c-11b21158bd32">1988</option><option data-label="1987" data-value="" data-price="0.0000" data-optionID="8222" data-bindID="00a2ee46-e0e8-469e-a80a-ba9241ba1143" value="00a2ee46-e0e8-469e-a80a-ba9241ba1143">1987</option><option data-label="1986" data-value="" data-price="0.0000" data-optionID="8223" data-bindID="e8bb8774-b338-4813-8139-3a806f24ca71" value="e8bb8774-b338-4813-8139-3a806f24ca71">1986</option><option data-label="1985" data-value="" data-price="0.0000" data-optionID="8224" data-bindID="6c23ea54-bf23-433c-8beb-d44d8869e2ca" value="6c23ea54-bf23-433c-8beb-d44d8869e2ca">1985</option><option data-label="1984" data-value="" data-price="0.0000" data-optionID="8225" data-bindID="cdca5e7e-616e-4ebc-b0dc-a9aaa67fd7ec" value="cdca5e7e-616e-4ebc-b0dc-a9aaa67fd7ec">1984</option><option data-label="1983" data-value="" data-price="0.0000" data-optionID="8226" data-bindID="170c2801-3d7f-45b1-817f-3fa40d297693" value="170c2801-3d7f-45b1-817f-3fa40d297693">1983</option><option data-label="1982" data-value="" data-price="0.0000" data-optionID="8227" data-bindID="c4cbbe9a-1a51-4ae1-abdf-2896719dc01e" value="c4cbbe9a-1a51-4ae1-abdf-2896719dc01e">1982</option><option data-label="1981" data-value="" data-price="0.0000" data-optionID="8228" data-bindID="8bbc66e6-5ef0-429c-ab65-e10c5c17a818" value="8bbc66e6-5ef0-429c-ab65-e10c5c17a818">1981</option></select></div></div></div><div class="elementRow"><div class="elementContainer field_2857 " id="elementContainer_2863"><label for="el_2863" class="required">Planned Visit Date* <span class="labelXtra"> (mm/dd/yyyy)</span></label><div class="elementBody"><input type="text" name="el_2863" data-elbindid="2857" data-prefill="false" data-prefillDataField="" id="el_2863" value="" size="10" maxlength="255" class="datePicker fsValidate[required,USdate]" /><script type="text/javascript"> $j(document).ready(function(){ $j("#el_2863").datepicker( { dateFormat: "mm/dd/yy" } ); }); </script></div></div></div><div class="elementRow"><div class="elementContainer field_2858 " id="elementContainer_2864"><label for="el_2864">Special Requests </label><div class="elementBody"><div class="descText">people / places you would like to see, etc&#8203;</div><textarea name="el_2864" id="el_2864" data-prefill="false" data-prefillDataField="false" rows="4" cols="32"></textarea></div></div></div></div> <div id="pageControls_90" class="pageControls">
									
									<div class="userConfirmation">
										<label class=""><input type="checkbox" id="userConfirmationToggle_90" name="userConfirmationToggle" class="userConfirmationToggle" value="1">Please send a confirmation email to the address below:</label><br>
										<input type="text" name="userConfirmationEmail" id="userConfirmationEmail_90" value="my email address" class="userConfirmationEmail fsValidate[email]" disabled>
									</div>
								</div>
							

							<div class="pageControls" style="border:0">
						
						<div class="pageBreak"><input type="button" name="prevPage_90" id="prevPage_90" class="prevPage" value="&lt; Back"> <span class="pagenum" id="pagenum_90"></span> <input type="button" class="nextPage" name="nextPage_90" id="nextPage_90" value="Next &gt;"> <input type="button" name="submitBtn" data-submitbuttontext="Send" value="Send" class="submitBtn" id="submitBtn_90"></div> </div>  <div class="hydraulics" data-thisIDSuffix=""><input type="text" name="hydraulics" id="hydraulics_90" value="" tabindex="-1" autocomplete="off"></div></div><input type="hidden" name="cmd_cf_forms" class="cmd_cf_forms" value=""><input type="hidden" name="formID" value="90"> <input type="hidden" name="submitID" value="0"> <input type="hidden" name="revisionNumber" value="2"><input type="hidden" name="requestMode" value="direct"><input type="hidden" class="hiddenElements" name="hiddenElements" value=""><input type="hidden" class="idSuffix" name="idSuffix" value=""><input type='hidden' name='formNonce' value='CA6DD5D3-E8D9-888E-ADAC564E93D67B56'>
</form>

				</div>

		
</body>
</html>
