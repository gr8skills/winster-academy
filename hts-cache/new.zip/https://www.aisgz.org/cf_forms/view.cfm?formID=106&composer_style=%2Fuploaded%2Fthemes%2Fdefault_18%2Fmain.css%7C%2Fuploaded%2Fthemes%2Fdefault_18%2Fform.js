<!DOCTYPE html>
<html class="fsComposerFormEmbed">


<head><script type="text/javascript" src="/cf_scripts/scripts/cfform.js"></script>
<script type="text/javascript" src="/cf_scripts/scripts/masks.js"></script>

	<meta http-equiv="Content-type" content="text/html; charset=utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" >

	<script src="https://securejs.finalsite.com/190215/javascript/jQuery/jquery.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="https://securejs.finalsite.com/190215/javascript/jQuery/jquery-migrate-1.2.1.fs-modified.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="https://securejs.finalsite.com/190215/javascript/jQuery/jquery.ui.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="https://securejs.finalsite.com/190215/javascript/iFrameResizer/iframeResizer.contentWindow.min.js" type="text/javascript" charset="utf-8"></script>
	<script type="text/javascript" charset="utf-8">
		pathprefix = "../";
	</script>
   	<script src="https://securejs.finalsite.com/190215/javascript/fs_global.js" type="text/javascript" charset="utf-8"></script>
	<script type="text/javascript" charset="utf-8">
		$j = jQuery.noConflict();
		var siteDatemask = "md";
		var siteTimemask = "12";

		window.name = 'finalsiteadmin_aisgzorg';

		addHeight = 70;

		function popMedia(thevar) {
			var mh_url = pathprefix + "cf_media/popheight.cfm";

			mediaAction(thevar);
		}

		$j(document).ready(function(){
			$j('#leftFrame .btnLink').removeClass('on').each(function(i){
				if( $j(this).attr('href') == document.location.pathname + document.location.search ){
					$j(this).addClass('on');
				}
			});
		});

		siteurl = "https://www.aisgz.org";
		siteSSLurl = "https://www.aisgz.org";
		isEditor = true;
		basepath = '../';
		baseurl = "../";

	</script>
	<script src="scripts/adminview.js?decache=20111004064200" type="text/javascript" charset="utf-8"></script>

	
					<link rel="stylesheet" href="../uploaded/themes/default_18/main.css" type="text/css" media="screen" charset="utf-8">
				
					<script src="../uploaded/themes/default_18/form.js" type="text/javascript" charset="utf-8"></script>
				
	<link rel="stylesheet" href="https://www.aisgz.org/styles.cfm" type="text/css" media="screen" charset="utf-8">
<script src="https://securejs.finalsite.com/190215/javascript/jQuery/jquery-migrate-1.2.1.fs-modified.js?f=0" type="javascript"></script>

					<style type="text/css">
						.required{ color:#990033; font-weight:bold; }
					</style>

					<link rel="stylesheet" href="https://www.aisgz.org/cf_forms/scripts/formPlugin.css?decache=CA8863AD-9105-D34E-87F3C0ED9781FF3C" type="text/css" charset="utf-8">

					<link rel="stylesheet" href="https://securejs.finalsite.com/190215/javascript/jQuery/themes/base/ui.all.css?decache=190215" type="text/css" title="no title" charset="utf-8">
					<link rel="stylesheet" href="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/validationEngine.jquery.css?decache=190215" type="text/css" charset="utf-8" />
					<link rel="stylesheet" href="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/fsNumberSpinner/jquery.fsNumberSpinner.css?decache=190215" type="text/css" charset="utf-8" />

					
					

					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/jquery.ui.min.js?decache=190215" type="text/javascript"></script>

					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/jquery.json.js?decache=190215" type="text/javascript"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/jquery.base64.js?decache=190215" type="text/javascript"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/jquery.finalsiteValidator.min.js?decache=190215" type="text/javascript" charset="utf-8"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/jquery.uuid.min.js?decache=190215" type="text/javascript" charset="utf-8"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/jquery.finalsiteSumInputs.min.js?decache=190215" type="text/javascript" charset="utf-8"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/jquery.scrollTo-1.4.2-min.js?decache=190215" type="text/javascript"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/autonumeric/autoNumeric.min.js?decache=190215" type="text/javascript"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/jquery.autoLoader.js?decache=190215" type="text/javascript"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/fsNumberSpinner/jquery.fsNumberSpinner.min.js?decache=190215" type="text/javascript"></script>
					<script src="https://securejs.finalsite.com/190215/javascript/jQuery/plugins/fsNumberBox/jquery.fsNumberBox.min.js?decache=190215" type="text/javascript"></script>

					
					

					<script type="text/javascript" charset="utf-8">
						// <![CDATA[

						// we need to count how many forms require a warn before unload
						// for example, banners do not
						var warnBeforeUnloadCount = 0;

						// ]]>
					</script>

					<script type="text/javascript" charset="utf-8">
						var jsPath = "https://www.aisgz.org/";
						var formPluginRequestMode = "direct";

						// set our options for this form
						$j(document).ready(function() {
							

							$j("#form_106").data( "formOptions", {"submitButtonText":"Send","formWidth":950,"expiredFormText":"This form has expired.","emailAddressAlias":"donotreply@aisgz.org","maxFormWidth":938,"defaultLabelPosition":"top","defaultTipPosition":"below"} );
							
						} );

						// we will keep extending this object
						fs = {};
						isAdmin = false;
						// for date conditionals
						nowTS = 201905171622;
					</script>
					
						
						<script src="https://www.aisgz.org/cf_forms/scripts/formPlugin.min.js?decache=CA8863AD-9105-D34E-87F3C0ED9781FF3C" type="text/javascript" charset="utf-8"></script>
					
					<script type="text/javascript" charset="utf-8">
						// <![CDATA[
						warnBeforeUnloadCount++;
						// ]]>
					</script>
				
				<script type="text/javascript" charset="utf-8">
					isQuiz = false;
					
				</script>
			<script type="text/javascript">
<!--
    _CF_checkform_106 = function(_CF_this)
    {
        //reset on submit
        _CF_error_exists = false;
        _CF_error_messages = new Array();
        _CF_error_fields = new Object();
        _CF_FirstErrorField = null;


        //display error messages and return success
        if( _CF_error_exists )
        {
            if( _CF_error_messages.length > 0 )
            {
                // show alert() message
                _CF_onErrorAlert(_CF_error_messages);
                // set focus to first form error, if the field supports js focus().
                if( _CF_this[_CF_FirstErrorField].type == "text" )
                { _CF_this[_CF_FirstErrorField].focus(); }

            }
            return false;
        }else {
            return true;
        }
    }
//-->
</script>
</head>


<body>

	

	
	<a name="formAnchor_106"></a>

	

				<div class="subGroup">

					
					<script type="text/javascript">
						cp = {};
						fs = $j.extend( fs, {"HIDDENELEMENTS":"","formID":0,"CMD_CF_FORMS":"","revisionNumber":0,"REQUESTMODE":"direct","IFRAMEMODE":false,"submissionExists":0,"submitID":0,"ISFRAMED":false} );
						idSuffix = "";
						hasReg = false;
						rg = {};
						wlClaim = [];
						wlClaimBindIDs = [];
						regKey = "";
						ro = {};
						adminBypass = false;
						aSess = false;

						
						
					</script>

					
					<form name="form_106" id="form_106" action="/cf_forms/view.cfm?composer_style=%252Fuploaded%252Fthemes%252Fdefault%5F18%252Fmain%2Ecss%257C%252Fuploaded%252Fthemes%252Fdefault%5F18%252Fform%2Ejs%2C%2Fuploaded%2Fthemes%2Fdefault%5F18%2Fmain%2Ecss%7C%2Fuploaded%2Fthemes%2Fdefault%5F18%2Fform%2Ejs&CSB=off&adminBypass=false&verbose=0&formID=106#formAnchor_106" method="post" class="cf_form disableEnter" enctype="multipart/form-data" onsubmit="return _CF_checkform_106(this)"><div class="mainGroupSub targetForm" id="targetForm_106"><div class="formPage" id="formPage_106_1"><div class="elementRow"><div class="elementContainer field_3435 " id="elementContainer_4133"><label for="el_4133" class="required">与学校关系* </label><div class="elementBody"><select name="el_4133" id="el_4133" class="fsValidate[required]" data-elbindid="3435" data-max="999999"><option value="">Please Select&hellip;</option><option data-label="Current Parent" data-value="Item One" data-price="0.0000" data-optionID="21426" data-bindID="2c5c7364-e70e-4239-bfea-58448d41682d" value="2c5c7364-e70e-4239-bfea-58448d41682d">Current Parent</option><option data-label="Alumni Parent" data-value="Item Two" data-price="0.0000" data-optionID="21427" data-bindID="11fad826-92f9-4e1c-a623-dedcdd3a76dc" value="11fad826-92f9-4e1c-a623-dedcdd3a76dc">Alumni Parent</option><option data-label="Grandparent" data-value="Item Three" data-price="0.0000" data-optionID="21428" data-bindID="1ec04d6f-7199-43a1-a424-52867e8cfa50" value="1ec04d6f-7199-43a1-a424-52867e8cfa50">Grandparent</option><option data-label="Faculty/Staff" data-value="" data-price="0.0000" data-optionID="21429" data-bindID="e759d0d0-228e-42ae-aaaa-6e14c4a43106" value="e759d0d0-228e-42ae-aaaa-6e14c4a43106">Faculty/Staff</option><option data-label="Alumin" data-value="" data-price="0.0000" data-optionID="21430" data-bindID="570ac402-014d-466a-8690-06aeededf751" value="570ac402-014d-466a-8690-06aeededf751">Alumin</option></select></div></div></div><div class="elementRow"><div class="elementContainer field_3666 " id="elementContainer_4134"><div class="textblock "><h4>1. 捐赠者信息</h4></div></div></div><div class="elementRow"><div class="elementContainer field_3436 " id="elementContainer_4135"><label for="el_4135" class="required">捐赠人姓名* </label><div class="elementBody"><input type="text" name="el_4135" data-elbindid="3436" data-prefill="NO" data-prefillDataField="NO" id="el_4135" value="" size="50" maxlength="255" class="fsValidate[required]" /></div></div></div><div class="elementRow"><div class="elementContainer field_3437 " id="elementContainer_4136"><label for="el_4136">学生姓名（如适用） </label><div class="elementBody"><input type="text" name="el_4136" data-elbindid="3437" data-prefill="false" data-prefillDataField="false" id="el_4136" value="" size="50" maxlength="255" /></div></div></div><div class="elementRow"><div class="elementContainer field_3440 " id="elementContainer_4137"><label for="el_4137">学生班级（如适用） </label><div class="elementBody"><input type="text" name="el_4137" data-elbindid="3440" data-prefill="false" data-prefillDataField="false" id="el_4137" value="" size="50" maxlength="255" /></div></div></div><div class="elementRow"><div class="elementContainer field_3438 " id="elementContainer_4138"><label for="el_4138" class="required">Email * </label><div class="elementBody"><input type="text" name="el_4138" data-elbindid="3438" data-prefill="NO" data-prefillDataField="Email" id="el_4138" value="" size="50" maxlength="255" class="fsValidate[required,email]" /></div></div></div><div class="elementRow"><div class="elementContainer field_3439 " id="elementContainer_4139"><label for="el_4139" class="required">手机* </label><div class="elementBody"><input type="text" name="el_4139" data-elbindid="3439" data-prefill="NO" data-prefillDataField="NO" id="el_4139" value="" size="50" maxlength="255" class="fsValidate[required]" /></div></div></div><div class="elementRow"><div class="elementContainer field_3667 " id="elementContainer_4140"><div class="textblock "><h4>2. 捐赠信息</h4></div></div></div><div class="elementRow"><div class="elementContainer field_3670 " id="elementContainer_4141"><div class="groupLabel required"><label for="el_4141" style="overflow: hidden;">我/我们承诺为年度基金捐赠如下款项：*</label></div><div class="elementBody"><fieldset id="el_4141" class="fsValidate[required]"><label for="el_4141_0" class="horizontal"><input data-label="RMB1,000" data-value="" data-price="0.0000" data-optionID="21431" data-bindID="31503173-2e32-4810-ab72-999185a98043" id="el_4141_0" data-elbindid="3670" data-max="999999" type="checkbox" value="31503173-2e32-4810-ab72-999185a98043" name="el_4141" > RMB1,000&nbsp; </label><label for="el_4141_1" class="horizontal"><input data-label="RMB2,000" data-value="" data-price="0.0000" data-optionID="21432" data-bindID="226812b2-d8d0-4a5f-9444-bc3248c209f9" id="el_4141_1" data-elbindid="3670" data-max="999999" type="checkbox" value="226812b2-d8d0-4a5f-9444-bc3248c209f9" name="el_4141" > RMB2,000&nbsp; </label><label for="el_4141_2" class="horizontal"><input data-label="RMB5,000" data-value="" data-price="0.0000" data-optionID="21433" data-bindID="61a1d8ce-bf36-4105-ac8b-aa28204e2b52" id="el_4141_2" data-elbindid="3670" data-max="999999" type="checkbox" value="61a1d8ce-bf36-4105-ac8b-aa28204e2b52" name="el_4141" > RMB5,000&nbsp; </label><label for="el_4141_3" class="horizontal"><input data-label="RMB10,000" data-value="" data-price="0.0000" data-optionID="21434" data-bindID="a4c4024e-7191-4b22-81cb-09b2d4e06d4b" id="el_4141_3" data-elbindid="3670" data-max="999999" type="checkbox" value="a4c4024e-7191-4b22-81cb-09b2d4e06d4b" name="el_4141" > RMB10,000&nbsp; </label><label for="el_4141_4" class="horizontal"><input data-label="RMB20,000" data-value="" data-price="0.0000" data-optionID="21435" data-bindID="aaaaf5d8-7fe2-4d78-8ddf-f249cd11094a" id="el_4141_4" data-elbindid="3670" data-max="999999" type="checkbox" value="aaaaf5d8-7fe2-4d78-8ddf-f249cd11094a" name="el_4141" > RMB20,000&nbsp; </label><label for="el_4141_5" class="horizontal"><input data-label="RMB50,000" data-value="" data-price="0.0000" data-optionID="21436" data-bindID="cab77217-329f-4323-8fc7-47ed095f13c2" id="el_4141_5" data-elbindid="3670" data-max="999999" type="checkbox" value="cab77217-329f-4323-8fc7-47ed095f13c2" name="el_4141" > RMB50,000&nbsp; </label><label for="el_4141_6" class="horizontal"><input data-label="RMB100,000" data-value="" data-price="0.0000" data-optionID="21437" data-bindID="a3a11686-6524-4c67-9f8b-545457744c5d" id="el_4141_6" data-elbindid="3670" data-max="999999" type="checkbox" value="a3a11686-6524-4c67-9f8b-545457744c5d" name="el_4141" > RMB100,000&nbsp; </label><label for="el_4141_7" class="horizontal"><input data-label="Other amount" data-value="" data-price="0.0000" data-optionID="21438" data-bindID="c54dbed8-dba9-45d2-91f7-e16a2ef72190" id="el_4141_7" data-elbindid="3670" data-max="999999" type="checkbox" value="c54dbed8-dba9-45d2-91f7-e16a2ef72190" name="el_4141" > Other amount&nbsp; </label></fieldset></div></div></div><div class="elementRow"><div class="elementContainer field_3671 " id="elementContainer_4142"><label for="el_4142">其他 </label><div class="elementBody"><input type="text" name="el_4142" data-elbindid="3671" data-prefill="false" data-prefillDataField="false" id="el_4142" value="" size="40" maxlength="255" /></div></div></div><div class="elementRow"><div class="elementContainer field_3672 " id="elementContainer_4143"><div class="groupLabel"><label for="el_4143" style="overflow: hidden;">捐赠鸣谢</label></div><div class="elementBody"><fieldset id="el_4143"><label for="el_4143_0" class="horizontal"><input data-label="匿名捐赠" data-value="" data-price="0.0000" data-optionID="21439" data-bindID="63a2518e-c77e-4726-8cc5-286b47125a80" id="el_4143_0" data-elbindid="3672" data-max="999999" type="checkbox" value="63a2518e-c77e-4726-8cc5-286b47125a80" name="el_4143" > 匿名捐赠&nbsp; </label></fieldset></div></div></div><div class="elementRow"><div class="elementContainer field_3673 " id="elementContainer_4144"><label for="el_4144">我/我们以如下名义实名捐赠 </label><div class="elementBody"><input type="text" name="el_4144" data-elbindid="3673" data-prefill="false" data-prefillDataField="false" id="el_4144" value="" size="40" maxlength="255" /></div></div></div><div class="elementRow"><div class="elementContainer field_3674 " id="elementContainer_4145"><div class="groupLabel"><label for="el_4145" style="overflow: hidden;">捐赠方式</label></div><div class="elementBody"><fieldset id="el_4145"><label for="el_4145_0" class="horizontal"><input data-label="微信支付" data-value="Checkbox" data-price="0.0000" data-optionID="21440" data-bindID="b21355d9-171b-4dad-9942-946b1f68b25d" id="el_4145_0" data-elbindid="3674" data-max="999999" type="checkbox" value="b21355d9-171b-4dad-9942-946b1f68b25d" name="el_4145" > 微信支付&nbsp; </label><label for="el_4145_1" class="horizontal"><input data-label="银行转账" data-value="" data-price="0.0000" data-optionID="21441" data-bindID="e837eff9-55d8-4dd7-b2fc-34704791a9f5" id="el_4145_1" data-elbindid="3674" data-max="999999" type="checkbox" value="e837eff9-55d8-4dd7-b2fc-34704791a9f5" name="el_4145" > 银行转账&nbsp; </label><label for="el_4145_2" class="horizontal"><input data-label="现金/信用卡" data-value="" data-price="0.0000" data-optionID="21442" data-bindID="95862ece-707a-4efe-bc20-cf88c25fff10" id="el_4145_2" data-elbindid="3674" data-max="999999" type="checkbox" value="95862ece-707a-4efe-bc20-cf88c25fff10" name="el_4145" > 现金/信用卡&nbsp; </label></fieldset></div></div></div><div class="elementRow"><div class="elementContainer field_3668 " id="elementContainer_4146"><div class="textblock "><h4>3. 对年度基金的建议</h4></div></div></div><div class="elementRow"><div class="elementContainer field_3669 " id="elementContainer_4147"><textarea name="el_4147" id="el_4147" data-prefill="false" data-prefillDataField="false" rows="4" cols="50"></textarea></div></div><div class="elementRow"><div class="elementContainer field_3451 " id="elementContainer_4148"><div class="textblock "><p class="p1">年度基金只接受在读学生家庭及校友家庭的捐赠。如需了解更多信息或是做大额捐赠， 请联系：</p><p class="p1">邢映芳 （Ava Xing）</p><p class="p1">发展部副总监</p><p class="p1">Email: axing@aisgz.org</p><p class="p1">电话: +8620 3213 5555 | Ext: 5420 </p></div></div></div></div> <div id="pageControls_106" class="pageControls">
									
									<div class="userConfirmation">
										<label class="required"><input type="checkbox" id="userConfirmationToggle_106" name="userConfirmationToggle" class="userConfirmationToggle" value="1" checked disabled>Please send a confirmation email to the address below*:</label><br>
										<input type="text" name="userConfirmationEmail" id="userConfirmationEmail_106" value="my email address" class="userConfirmationEmail fsValidate[required,email]">
									</div>
								</div>
							

							<div class="pageControls" style="border:0">
						
						<div class="pageBreak"><input type="button" name="prevPage_106" id="prevPage_106" class="prevPage" value="&lt; Back"> <span class="pagenum" id="pagenum_106"></span> <input type="button" class="nextPage" name="nextPage_106" id="nextPage_106" value="Next &gt;"> <input type="button" name="submitBtn" data-submitbuttontext="Send" value="Send" class="submitBtn" id="submitBtn_106"></div> </div>  <div class="hydraulics" data-thisIDSuffix=""><input type="text" name="hydraulics" id="hydraulics_106" value="" tabindex="-1" autocomplete="off"></div></div><input type="hidden" name="cmd_cf_forms" class="cmd_cf_forms" value=""><input type="hidden" name="formID" value="106"> <input type="hidden" name="submitID" value="0"> <input type="hidden" name="revisionNumber" value="7"><input type="hidden" name="requestMode" value="direct"><input type="hidden" class="hiddenElements" name="hiddenElements" value=""><input type="hidden" class="idSuffix" name="idSuffix" value=""><input type='hidden' name='formNonce' value='CA88657C-01BC-FBDC-5D7B2BAC7EF04523'>
</form>

				</div>

		
</body>
</html>
